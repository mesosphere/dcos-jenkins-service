jenkins-standalone
==================

Jenkins standalone instance package
